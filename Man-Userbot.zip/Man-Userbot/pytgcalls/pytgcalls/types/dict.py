from ..types.py_object import PyObject


class Dict(dict, PyObject):
    pass
