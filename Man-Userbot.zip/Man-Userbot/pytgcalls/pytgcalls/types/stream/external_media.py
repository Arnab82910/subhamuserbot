from enum import auto

from ..flag import Flag


class ExternalMedia(Flag):
    AUDIO = auto()
    VIDEO = auto()
