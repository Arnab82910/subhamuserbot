class CallSources:
    def __init__(self):
        self.camera = dict()
        self.presentation = dict()
